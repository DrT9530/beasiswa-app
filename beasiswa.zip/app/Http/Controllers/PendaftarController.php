<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pendaftar; // Memanggil model Pendaftar

class PendaftarController extends Controller
{
    public function store(Request $request)
    {
        // 1. Validasi data (memastikan tidak ada yang kosong)
        $request->validate([
            'nama' => 'required',
            'universitas' => 'required',
            'nim' => 'required',
            'jurusan' => 'required',
        ]);

        // 2. Simpan data ke Database MySQL
        Pendaftar::create([
            'nama' => $request->nama,
            'universitas' => $request->universitas,
            'nim' => $request->nim,
            'jurusan' => $request->jurusan,
        ]);

        // 3. Kembalikan user ke halaman form dengan pesan sukses
        return back()->with('success', 'Pendaftaran berhasil dikirim! Tim kami akan segera meninjau datamu.');
    }
}